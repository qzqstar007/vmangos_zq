/* 
* 20210731110900_logs.sql 
*/ 
DROP PROCEDURE IF EXISTS add_migration;
delimiter ??
CREATE PROCEDURE `add_migration`()
BEGIN
DECLARE v INT DEFAULT 1;
SET v = (SELECT COUNT(*) FROM `migrations` WHERE `id`='20210731110900');
IF v=0 THEN
INSERT INTO `migrations` VALUES ('20210731110900');
-- Add your query below.


DROP TABLE IF EXISTS `system_fingerprint_usage`;

CREATE TABLE `system_fingerprint_usage` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fingerprint` int(10) unsigned NOT NULL,
  `account` int(10) unsigned NOT NULL,
  `ip` varchar(16) NOT NULL,
  `realm` int(10) unsigned NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `architecture` varchar(16) DEFAULT NULL,
  `cputype` varchar(64) DEFAULT NULL,
  `activecpus` int(10) unsigned DEFAULT NULL,
  `totalcpus` int(10) unsigned DEFAULT NULL,
  `pagesize` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fingerprint` (`fingerprint`),
  KEY `account` (`account`),
  KEY `ip` (`ip`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8;

-- End of migration.
END IF;
END??
delimiter ; 
CALL add_migration();
DROP PROCEDURE IF EXISTS add_migration;
 
 
/* 
* 20220102005704_logs.sql 
*/ 
DROP PROCEDURE IF EXISTS add_migration;
delimiter ??
CREATE PROCEDURE `add_migration`()
BEGIN
DECLARE v INT DEFAULT 1;
SET v = (SELECT COUNT(*) FROM `migrations` WHERE `id`='20220102005704');
IF v=0 THEN
INSERT INTO `migrations` VALUES ('20220102005704');
-- Add your query below.


-- This was never implemented.
ALTER TABLE `logs_characters`
	DROP COLUMN `clientHash`;


-- End of migration.
END IF;
END??
delimiter ; 
CALL add_migration();
DROP PROCEDURE IF EXISTS add_migration;
 
 
/* 
* 20220523001700_logs.sql 
*/ 
DROP PROCEDURE IF EXISTS add_migration;
delimiter ??
CREATE PROCEDURE `add_migration`()
BEGIN
DECLARE v INT DEFAULT 1;
SET v = (SELECT COUNT(*) FROM `migrations` WHERE `id`='20220523001700');
IF v=0 THEN
INSERT INTO `migrations` VALUES ('20220523001700');
-- Add your query below.


-- Unused
DROP TABLE IF EXISTS `logs_behavior`;


-- End of migration.
END IF;
END??
delimiter ;
CALL add_migration();
DROP PROCEDURE IF EXISTS add_migration;

DROP TABLE IF EXISTS `logs_behavior`;
 
 
/* 
* 20220601082200_logs.sql 
*/ 
DROP PROCEDURE IF EXISTS add_migration;
delimiter ??
CREATE PROCEDURE `add_migration`()
BEGIN
DECLARE v INT DEFAULT 1;
SET v = (SELECT COUNT(*) FROM `migrations` WHERE `id`='20220601082200');
IF v=0 THEN
INSERT INTO `migrations` VALUES ('20220601082200');
-- Add your query below.

-- Now unused tables
DROP TABLE IF EXISTS `logs_behavior`;
DROP TABLE IF EXISTS `logs_characters`;
DROP TABLE IF EXISTS `logs_chat`;
DROP TABLE IF EXISTS `logs_movement`;
DROP TABLE IF EXISTS `logs_spamdetect`;
DROP TABLE IF EXISTS `logs_warden`;

-- New unified table
DROP TABLE IF EXISTS `logs_player`;
CREATE TABLE `logs_player` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `time` TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `type` ENUM(
    'Basic', 'WorldPacket', 'Chat', 'BG', 'Character', 'Honor', 'RA', 'DBError', 'DBErrorFix', 'ClientIds',
    'Loot', 'LevelUp', 'Performance', 'MoneyTrade', 'GM', 'GMCritical', 'ChatSpam', 'Anticheat'
  ) NOT NULL,
  `subtype` VARCHAR(20),
  `account` INT UNSIGNED NOT NULL,
  `ip` VARCHAR(16),
  `guid` INT,
  `name` VARCHAR(20),
  `map` INT UNSIGNED,
  `pos_x` FLOAT,
  `pos_y` FLOAT,
  `pos_z` FLOAT,
  `text` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`) , KEY (`account`) , KEY (`guid`) , KEY (`name`)
) ENGINE=MYISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='player and account specific log entries';

-- End of migration.
END IF;
END??
delimiter ;
CALL add_migration();
DROP PROCEDURE IF EXISTS add_migration;

DROP TABLE IF EXISTS `logs_behavior`;
 
 
/* 
* 20220913193700_logs.sql 
*/ 
DROP PROCEDURE IF EXISTS add_migration;
delimiter ??
CREATE PROCEDURE `add_migration`()
BEGIN
DECLARE v INT DEFAULT 1;
SET v = (SELECT COUNT(*) FROM `migrations` WHERE `id`='20220913193700');
IF v=0 THEN
INSERT INTO `migrations` VALUES ('20220913193700');

ALTER TABLE `logs_trade` CHANGE `type` `type` ENUM('AuctionBid','AuctionBuyout','BuyItem','SellItem','GM','Mail','QuestMaxLevel','Quest','Loot','Trade','') CHARSET utf8 COLLATE utf8_general_ci DEFAULT '' NOT NULL, CHARSET=utf8mb3;


-- End of migration.
END IF;
END??
delimiter ; 
CALL add_migration();
DROP PROCEDURE IF EXISTS add_migration;
 
 
/* 
* 20221008210304_logs.sql 
*/ 
DROP PROCEDURE IF EXISTS add_migration;
delimiter ??
CREATE PROCEDURE `add_migration`()
BEGIN
DECLARE v INT DEFAULT 1;
SET v = (SELECT COUNT(*) FROM `migrations` WHERE `id`='20221008210304');
IF v=0 THEN
INSERT INTO `migrations` VALUES ('20221008210304');
-- Add your query below.

ALTER TABLE `logs_player` CHANGE `text` `text` VARCHAR(512) CHARSET utf8 COLLATE utf8_general_ci NOT NULL, CHARSET=utf8mb3; 

-- End of migration.
END IF;
END??
delimiter ; 
CALL add_migration();
DROP PROCEDURE IF EXISTS add_migration;
 
 
