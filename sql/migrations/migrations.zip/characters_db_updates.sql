/* 
* 20220813085336_characters.sql 
*/ 
DROP PROCEDURE IF EXISTS add_migration;
delimiter ??
CREATE PROCEDURE `add_migration`()
BEGIN
DECLARE v INT DEFAULT 1;
SET v = (SELECT COUNT(*) FROM `migrations` WHERE `id`='20220813085336');
IF v=0 THEN
INSERT INTO `migrations` VALUES ('20220813085336');
-- Add your query below.


-- Add spell crit to exported character stats table.
ALTER TABLE `character_stats`
	ADD COLUMN `spell_crit_chance` FLOAT NOT NULL DEFAULT '0' AFTER `ranged_crit_chance`;

-- Add bonus spell damage and healing to exported character stats table.
ALTER TABLE `character_stats`
	ADD COLUMN `spell_damage` INT(10) UNSIGNED NOT NULL DEFAULT '0' AFTER `ranged_attack_power`,
	ADD COLUMN `spell_healing` INT(10) UNSIGNED NOT NULL DEFAULT '0' AFTER `spell_damage`;


-- End of migration.
END IF;
END??
delimiter ; 
CALL add_migration();
DROP PROCEDURE IF EXISTS add_migration;
 
 
/* 
* 20221001202815_characters.sql 
*/ 
DROP PROCEDURE IF EXISTS add_migration;
delimiter ??
CREATE PROCEDURE `add_migration`()
BEGIN
DECLARE v INT DEFAULT 1;
SET v = (SELECT COUNT(*) FROM `migrations` WHERE `id`='20221001202815');
IF v=0 THEN
INSERT INTO `migrations` VALUES ('20221001202815');
-- Add your query below.


-- Dumping structure for table characters.account_data
CREATE TABLE IF NOT EXISTS `account_data` (
  `account` int(11) unsigned NOT NULL DEFAULT '0',
  `type` int(11) unsigned NOT NULL DEFAULT '0',
  `time` bigint(11) unsigned NOT NULL DEFAULT '0',
  `data` longblob NOT NULL,
  PRIMARY KEY (`account`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping structure for table characters.character_account_data
CREATE TABLE IF NOT EXISTS `character_account_data` (
  `guid` int(11) unsigned NOT NULL DEFAULT '0',
  `type` int(11) unsigned NOT NULL DEFAULT '0',
  `time` bigint(11) unsigned NOT NULL DEFAULT '0',
  `data` longblob NOT NULL,
  PRIMARY KEY (`guid`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- End of migration.
END IF;
END??
delimiter ; 
CALL add_migration();
DROP PROCEDURE IF EXISTS add_migration;
 
 
/* 
* 20241002031703_characters.sql 
*/ 
DROP PROCEDURE IF EXISTS add_migration;
DELIMITER ??
CREATE PROCEDURE `add_migration`()
BEGIN
DECLARE v INT DEFAULT 1;
SET v = (SELECT COUNT(*) FROM `migrations` WHERE `id`='20241002031703');
IF v = 0 THEN
INSERT INTO `migrations` VALUES ('20241002031703');
-- Add your query below.


-- Add instance id player logged out inside of to characters table to prevent exploits.
ALTER TABLE `characters`
	ADD COLUMN `instance_id` INT(11) UNSIGNED NOT NULL DEFAULT '0' AFTER `map`;


-- End of migration.
END IF;
END??
DELIMITER ;
CALL add_migration();
DROP PROCEDURE IF EXISTS add_migration;
 
 
/* 
* 20241113131610_characters.sql 
*/ 
DROP PROCEDURE IF EXISTS add_migration;
DELIMITER ??
CREATE PROCEDURE `add_migration`()
BEGIN
DECLARE v INT DEFAULT 1;
SET v = (SELECT COUNT(*) FROM `migrations` WHERE `id`='20241113131610');
IF v = 0 THEN
INSERT INTO `migrations` VALUES ('20241113131610');
-- Add your query below.


ALTER TABLE `characters`   
  ADD  INDEX `idx_instance` (`instance_id`);


-- End of migration.
END IF;
END??
DELIMITER ;
CALL add_migration();
DROP PROCEDURE IF EXISTS add_migration;
 
 
/* 
* 20241114131912_characters.sql 
*/ 
DROP PROCEDURE IF EXISTS add_migration;
DELIMITER ??
CREATE PROCEDURE `add_migration`()
BEGIN
DECLARE v INT DEFAULT 1;
SET v = (SELECT COUNT(*) FROM `migrations` WHERE `id`='20241114131912');
IF v = 0 THEN
INSERT INTO `migrations` VALUES ('20241114131912');
-- Add your query below.


ALTER TABLE `characters`
	CHANGE COLUMN `instance_id` `instance` INT(11) UNSIGNED NOT NULL DEFAULT '0' AFTER `map`;


-- End of migration.
END IF;
END??
DELIMITER ;
CALL add_migration();
DROP PROCEDURE IF EXISTS add_migration;
 
 
